module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},44416,e=>{"use strict";let t=e.i(22244).default.createPool({host:"127.0.0.1",port:process.env.DB_PORT||3306,user:"root",password:"root",database:"gimnasio",waitForConnections:!0,connectionLimit:10,queueLimit:0});e.s(["default",0,t])},11865,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),s=e.i(59756),n=e.i(61916),i=e.i(14444),o=e.i(37092),l=e.i(69741),u=e.i(16795),d=e.i(87718),c=e.i(95169),p=e.i(47587),R=e.i(66012),h=e.i(70101),E=e.i(26937),f=e.i(10372),v=e.i(93695);e.i(52474);var N=e.i(220),C=e.i(44416);async function T(e){let t=e.headers.get("x-user");if(!t)return new Response("No autorizado",{status:401});if("admin"!==JSON.parse(t).rol)return new Response("Solo admin",{status:403});let{searchParams:a}=new URL(e.url),r=a.get("bloque"),s=a.get("fechaInicio"),n=a.get("fechaFin");if(!r)return new Response("Bloque requerido",{status:400});try{console.log("=== ESTADÍSTICAS DE BLOQUE ==="),console.log("Bloque:",r),console.log("Rango:",s,"a",n);let e="1=1",t=[r];s&&n?(e="fecha BETWEEN ? AND ?",t=[r,s,n]):e="fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";let[a]=await C.default.query(`
      SELECT 
        COUNT(*) as total_reservas,
        SUM(asistio) as total_asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        COUNT(DISTINCT email) as alumnos_unicos,
        COUNT(DISTINCT fecha) as dias_activos,
        ROUND(COUNT(*) / COUNT(DISTINCT fecha), 2) as promedio_reservas_por_dia,
        MIN(fecha) as primera_fecha,
        MAX(fecha) as ultima_fecha
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
    `,t),[i]=await C.default.query(`
      SELECT 
        fecha,
        COUNT(*) as reservas,
        SUM(asistio) as asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        DAYNAME(fecha) as dia_semana
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
      GROUP BY fecha
      ORDER BY fecha DESC
      LIMIT 30
    `,t),[o]=await C.default.query(`
      SELECT 
        u.name,
        r.email,
        COUNT(*) as veces_reservado,
        SUM(r.asistio) as veces_asistido,
        ROUND((SUM(r.asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia
      FROM reservas r
      JOIN users u ON r.email = u.email
      WHERE r.bloque_horario = ? AND ${e}
      GROUP BY r.email
      ORDER BY veces_reservado DESC
      LIMIT 10
    `,t),[l]=await C.default.query(`
      SELECT 
        DAYNAME(fecha) as dia_semana,
        COUNT(*) as total_reservas,
        SUM(asistio) as total_asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        ROUND(COUNT(*) / COUNT(DISTINCT fecha), 2) as promedio_por_dia
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
      GROUP BY DAYOFWEEK(fecha), DAYNAME(fecha)
      ORDER BY DAYOFWEEK(fecha)
    `,t),[u]=await C.default.query(`
      SELECT 
        fecha,
        COUNT(*) as reservas,
        SUM(asistio) as asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia
      FROM reservas 
      WHERE bloque_horario = ? AND fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
      GROUP BY fecha
      ORDER BY fecha
    `,[r]),d={bloque:r,estadisticasGenerales:a[0],datosPorDia:i,alumnosFrecuentes:o,estadisticasDiaSemana:l,tendenciaReciente:u};return console.log("Resultado estadísticas bloque:",d),new Response(JSON.stringify(d),{status:200,headers:{"Content-Type":"application/json"}})}catch(e){return console.error("Error en estadísticas bloque:",e),new Response(JSON.stringify({error:"Error interno",message:e.message}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["GET",()=>T],71468);var m=e.i(71468);let O=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/admin/estadisticas-bloque/route",pathname:"/api/admin/estadisticas-bloque",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/admin/estadisticas-bloque/route.js",nextConfigOutput:"standalone",userland:m}),{workAsyncStorage:x,workUnitAsyncStorage:U,serverHooks:g}=O;function A(){return(0,r.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:U})}async function w(e,t,r){O.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let C="/api/admin/estadisticas-bloque/route";C=C.replace(/\/index$/,"")||"/";let T=await O.prepare(e,t,{srcPage:C,multiZoneDraftMode:!1});if(!T)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:m,params:x,nextConfig:U,parsedUrl:g,isDraftMode:A,prerenderManifest:w,routerServerContext:_,isOnDemandRevalidate:D,revalidateOnlyGenerated:S,resolvedPathname:y,clientReferenceManifest:q,serverActionsManifest:b}=T,M=(0,l.normalizeAppPath)(C),I=!!(w.dynamicRoutes[M]||w.routes[y]),P=async()=>((null==_?void 0:_.render404)?await _.render404(e,t,g,!1):t.end("This page could not be found"),null);if(I&&!A){let e=!!w.routes[y],t=w.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(U.experimental.adapterPath)return await P();throw new v.NoFallbackError}}let j=null;!I||O.isDev||A||(j="/index"===(j=y)?"/":j);let H=!0===O.isDev||!I,B=I&&!H;b&&q&&(0,i.setReferenceManifestsSingleton)({page:C,clientReferenceManifest:q,serverActionsManifest:b,serverModuleMap:(0,o.createServerModuleMap)({serverActionsManifest:b})});let k=e.method||"GET",L=(0,n.getTracer)(),F=L.getActiveScopeSpan(),Y={params:x,prerenderManifest:w,renderOpts:{experimental:{authInterrupts:!!U.experimental.authInterrupts},cacheComponents:!!U.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:U.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r)=>O.onRequestError(e,t,r,_)},sharedContext:{buildId:m}},$=new u.NodeNextRequest(e),K=new u.NodeNextResponse(t),W=d.NextRequestAdapter.fromNodeNextRequest($,(0,d.signalFromNodeResponse)(t));try{let i=async e=>O.handle(W,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=L.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${k} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${k} ${C}`)}),o=!!(0,s.getRequestMeta)(e,"minimalMode"),l=async s=>{var n,l;let u=async({previousCacheEntry:a})=>{try{if(!o&&D&&S&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await i(s);e.fetchMetrics=Y.renderOpts.fetchMetrics;let l=Y.renderOpts.pendingWaitUntil;l&&r.waitUntil&&(r.waitUntil(l),l=void 0);let u=Y.renderOpts.collectedTags;if(!I)return await (0,R.sendResponse)($,K,n,Y.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(n.headers);u&&(t[f.NEXT_CACHE_TAGS_HEADER]=u),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,r=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:N.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await O.onRequestError(e,t,{routerKind:"App Router",routePath:C,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:D})},_),t}},d=await O.handleResponse({req:e,nextConfig:U,cacheKey:j,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:D,revalidateOnlyGenerated:S,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:o});if(!I)return null;if((null==d||null==(n=d.value)?void 0:n.kind)!==N.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(l=d.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",D?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,h.fromNodeOutgoingHttpHeaders)(d.value.headers);return o&&I||c.delete(f.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,E.getCacheControlHeader)(d.cacheControl)),await (0,R.sendResponse)($,K,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};F?await l(F):await L.withPropagatedContext(e.headers,()=>L.trace(c.BaseServerSpan.handleRequest,{spanName:`${k} ${C}`,kind:n.SpanKind.SERVER,attributes:{"http.method":k,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await O.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:D})}),I)throw t;return await (0,R.sendResponse)($,K,new Response(null,{status:500})),null}}e.s(["handler",()=>w,"patchFetch",()=>A,"routeModule",()=>O,"serverHooks",()=>g,"workAsyncStorage",()=>x,"workUnitAsyncStorage",()=>U],11865)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__2037e409._.js.map