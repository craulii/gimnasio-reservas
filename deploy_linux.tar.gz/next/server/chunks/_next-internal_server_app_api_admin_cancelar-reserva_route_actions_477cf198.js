module.exports=[13340,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_cancelar-reserva_route_actions_477cf198.js.map