module.exports=[11313,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_procesar-ausencias_route_actions_5b86e793.js.map