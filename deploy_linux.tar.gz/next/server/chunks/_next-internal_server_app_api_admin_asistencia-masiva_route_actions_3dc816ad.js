module.exports=[42837,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_asistencia-masiva_route_actions_3dc816ad.js.map