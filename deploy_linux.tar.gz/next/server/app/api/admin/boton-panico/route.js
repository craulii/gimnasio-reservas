var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/boton-panico/route.js")
R.c("server/chunks/[root-of-the-server]__edbf59c6._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_boton-panico_route_actions_a902d40e.js")
R.m(50123)
module.exports=R.m(50123).exports
