var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/cancelar-reserva/route.js")
R.c("server/chunks/[root-of-the-server]__bd49dd37._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_cancelar-reserva_route_actions_477cf198.js")
R.m(73103)
module.exports=R.m(73103).exports
