var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/usuarios/route.js")
R.c("server/chunks/[root-of-the-server]__631ef039._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_usuarios_route_actions_eb13881e.js")
R.m(41575)
module.exports=R.m(41575).exports
