var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/exportar/route.js")
R.c("server/chunks/[root-of-the-server]__7ef39ca0._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_exportar_route_actions_5bfe2874.js")
R.m(43701)
module.exports=R.m(43701).exports
