var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reservas-por-bloque/route.js")
R.c("server/chunks/[root-of-the-server]__413adbf0._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reservas-por-bloque_route_actions_44f5b83b.js")
R.m(62428)
module.exports=R.m(62428).exports
