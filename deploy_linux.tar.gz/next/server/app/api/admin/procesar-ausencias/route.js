var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/procesar-ausencias/route.js")
R.c("server/chunks/[root-of-the-server]__26d60c02._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_procesar-ausencias_route_actions_5b86e793.js")
R.m(68227)
module.exports=R.m(68227).exports
