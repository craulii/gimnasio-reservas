var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test/route.js")
R.c("server/chunks/[root-of-the-server]__0f77b5aa._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_test_route_actions_546d6d37.js")
R.m(94720)
module.exports=R.m(94720).exports
