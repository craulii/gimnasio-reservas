module.exports=[7231,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_asistencia_route_actions_e5a6b46d.js.map