module.exports=[17378,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_estadisticas-alumno_route_actions_23c4cd00.js.map