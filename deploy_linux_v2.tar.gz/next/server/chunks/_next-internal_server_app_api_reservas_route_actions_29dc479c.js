module.exports=[87867,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reservas_route_actions_29dc479c.js.map