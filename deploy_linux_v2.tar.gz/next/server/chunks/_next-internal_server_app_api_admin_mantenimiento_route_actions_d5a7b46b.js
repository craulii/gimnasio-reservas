module.exports=[89042,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_mantenimiento_route_actions_d5a7b46b.js.map