module.exports=[12899,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_boton-panico_route_actions_a902d40e.js.map