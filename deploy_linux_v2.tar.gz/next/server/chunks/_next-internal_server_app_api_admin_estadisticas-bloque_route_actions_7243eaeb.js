module.exports=[50285,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_estadisticas-bloque_route_actions_7243eaeb.js.map