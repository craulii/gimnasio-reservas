module.exports=[17994,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_estadisticas_route_actions_38e7d173.js.map