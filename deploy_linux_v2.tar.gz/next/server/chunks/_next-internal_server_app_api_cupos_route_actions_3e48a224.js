module.exports=[63100,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cupos_route_actions_3e48a224.js.map