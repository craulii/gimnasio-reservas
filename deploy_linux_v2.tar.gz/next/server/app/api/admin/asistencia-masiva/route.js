var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/asistencia-masiva/route.js")
R.c("server/chunks/[root-of-the-server]__e6176105._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_asistencia-masiva_route_actions_3dc816ad.js")
R.m(32643)
module.exports=R.m(32643).exports
