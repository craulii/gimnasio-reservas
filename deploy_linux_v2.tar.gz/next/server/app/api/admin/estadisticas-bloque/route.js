var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/estadisticas-bloque/route.js")
R.c("server/chunks/[root-of-the-server]__2037e409._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_estadisticas-bloque_route_actions_7243eaeb.js")
R.m(11865)
module.exports=R.m(11865).exports
