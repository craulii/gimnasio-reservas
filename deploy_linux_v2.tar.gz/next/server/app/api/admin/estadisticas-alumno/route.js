var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/estadisticas-alumno/route.js")
R.c("server/chunks/[root-of-the-server]__92eefc56._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_estadisticas-alumno_route_actions_23c4cd00.js")
R.m(14357)
module.exports=R.m(14357).exports
