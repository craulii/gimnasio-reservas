var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/asistencia/route.js")
R.c("server/chunks/[root-of-the-server]__05a91ebc._.js")
R.c("server/chunks/[root-of-the-server]__bb33d2d0._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_asistencia_route_actions_e5a6b46d.js")
R.m(15488)
module.exports=R.m(15488).exports
