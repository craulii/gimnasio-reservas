var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__84e7390b._.js")
R.c("server/chunks/node_modules_next_1e37f256._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(32682)
module.exports=R.m(32682).exports
