module.exports=[2931,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_estadisticas-bloque_route_actions_149b653b.js.map