module.exports=[3376,(e,o,d)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app_favicon_ico_route_actions_643693a8.js.map