module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},51348,e=>{"use strict";let t=e.i(46735).default.createPool({host:"127.0.0.1",port:3306,user:"reservas_crauli",password:"CrauliChris69!",database:"reservas_gymusm",waitForConnections:!0,connectionLimit:10,queueLimit:0});e.s(["default",0,t])},7075,e=>{"use strict";var t=e.i(32029),a=e.i(16524),r=e.i(74223),s=e.i(7239),i=e.i(55854),n=e.i(87601),o=e.i(17342),l=e.i(93396),u=e.i(33318),d=e.i(30644),c=e.i(31369),p=e.i(82742),h=e.i(62648),R=e.i(40693),E=e.i(68833),f=e.i(87703),v=e.i(93695);e.i(75916);var C=e.i(93173),N=e.i(51348);async function m(e){let t=e.headers.get("x-user");if(!t)return new Response("No autorizado",{status:401});if("admin"!==JSON.parse(t).rol)return new Response("Solo admin",{status:403});let{searchParams:a}=new URL(e.url),r=a.get("bloque"),s=a.get("fechaInicio"),i=a.get("fechaFin");if(!r)return new Response("Bloque requerido",{status:400});try{console.log("=== ESTADÍSTICAS DE BLOQUE ==="),console.log("Bloque:",r),console.log("Rango:",s,"a",i);let e="1=1",t=[r];s&&i?(e="fecha BETWEEN ? AND ?",t=[r,s,i]):e="fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";let[a]=await N.default.query(`
      SELECT 
        COUNT(*) as total_reservas,
        SUM(asistio) as total_asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        COUNT(DISTINCT email) as alumnos_unicos,
        COUNT(DISTINCT fecha) as dias_activos,
        ROUND(COUNT(*) / COUNT(DISTINCT fecha), 2) as promedio_reservas_por_dia,
        MIN(fecha) as primera_fecha,
        MAX(fecha) as ultima_fecha
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
    `,t),[n]=await N.default.query(`
      SELECT 
        fecha,
        COUNT(*) as reservas,
        SUM(asistio) as asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        DAYNAME(fecha) as dia_semana
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
      GROUP BY fecha
      ORDER BY fecha DESC
      LIMIT 30
    `,t),[o]=await N.default.query(`
      SELECT 
        u.name,
        r.email,
        COUNT(*) as veces_reservado,
        SUM(r.asistio) as veces_asistido,
        ROUND((SUM(r.asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia
      FROM reservas r
      JOIN users u ON r.email = u.email
      WHERE r.bloque_horario = ? AND ${e}
      GROUP BY r.email
      ORDER BY veces_reservado DESC
      LIMIT 10
    `,t),[l]=await N.default.query(`
      SELECT 
        DAYNAME(fecha) as dia_semana,
        COUNT(*) as total_reservas,
        SUM(asistio) as total_asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia,
        ROUND(COUNT(*) / COUNT(DISTINCT fecha), 2) as promedio_por_dia
      FROM reservas 
      WHERE bloque_horario = ? AND ${e}
      GROUP BY DAYOFWEEK(fecha), DAYNAME(fecha)
      ORDER BY DAYOFWEEK(fecha)
    `,t),[u]=await N.default.query(`
      SELECT 
        fecha,
        COUNT(*) as reservas,
        SUM(asistio) as asistencias,
        ROUND((SUM(asistio) / COUNT(*)) * 100, 2) as porcentaje_asistencia
      FROM reservas 
      WHERE bloque_horario = ? AND fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
      GROUP BY fecha
      ORDER BY fecha
    `,[r]),d={bloque:r,estadisticasGenerales:a[0],datosPorDia:n,alumnosFrecuentes:o,estadisticasDiaSemana:l,tendenciaReciente:u};return console.log("Resultado estadísticas bloque:",d),new Response(JSON.stringify(d),{status:200,headers:{"Content-Type":"application/json"}})}catch(e){return console.error("Error en estadísticas bloque:",e),new Response(JSON.stringify({error:"Error interno",message:e.message}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["GET",()=>m],55894);var T=e.i(55894);let O=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/admin/estadisticas-bloque/route",pathname:"/api/admin/estadisticas-bloque",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/GYM - USM/gimnasio-reservas/src/app/api/admin/estadisticas-bloque/route.js",nextConfigOutput:"standalone",userland:T}),{workAsyncStorage:x,workUnitAsyncStorage:U,serverHooks:g}=O;function A(){return(0,r.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:U})}async function w(e,t,r){O.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let N="/api/admin/estadisticas-bloque/route";N=N.replace(/\/index$/,"")||"/";let m=await O.prepare(e,t,{srcPage:N,multiZoneDraftMode:!1});if(!m)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:T,params:x,nextConfig:U,parsedUrl:g,isDraftMode:A,prerenderManifest:w,routerServerContext:_,isOnDemandRevalidate:S,revalidateOnlyGenerated:D,resolvedPathname:y,clientReferenceManifest:q,serverActionsManifest:b}=m,M=(0,l.normalizeAppPath)(N),I=!!(w.dynamicRoutes[M]||w.routes[y]),P=async()=>((null==_?void 0:_.render404)?await _.render404(e,t,g,!1):t.end("This page could not be found"),null);if(I&&!A){let e=!!w.routes[y],t=w.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(U.experimental.adapterPath)return await P();throw new v.NoFallbackError}}let j=null;!I||O.isDev||A||(j="/index"===(j=y)?"/":j);let H=!0===O.isDev||!I,k=I&&!H;b&&q&&(0,n.setReferenceManifestsSingleton)({page:N,clientReferenceManifest:q,serverActionsManifest:b,serverModuleMap:(0,o.createServerModuleMap)({serverActionsManifest:b})});let B=e.method||"GET",L=(0,i.getTracer)(),F=L.getActiveScopeSpan(),Y={params:x,prerenderManifest:w,renderOpts:{experimental:{authInterrupts:!!U.experimental.authInterrupts},cacheComponents:!!U.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:U.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r)=>O.onRequestError(e,t,r,_)},sharedContext:{buildId:T}},$=new u.NodeNextRequest(e),G=new u.NodeNextResponse(t),K=d.NextRequestAdapter.fromNodeNextRequest($,(0,d.signalFromNodeResponse)(t));try{let n=async e=>O.handle(K,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=L.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${B} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${B} ${N}`)}),o=!!(0,s.getRequestMeta)(e,"minimalMode"),l=async s=>{var i,l;let u=async({previousCacheEntry:a})=>{try{if(!o&&S&&D&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await n(s);e.fetchMetrics=Y.renderOpts.fetchMetrics;let l=Y.renderOpts.pendingWaitUntil;l&&r.waitUntil&&(r.waitUntil(l),l=void 0);let u=Y.renderOpts.collectedTags;if(!I)return await (0,h.sendResponse)($,G,i,Y.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,R.toNodeOutgoingHttpHeaders)(i.headers);u&&(t[f.NEXT_CACHE_TAGS_HEADER]=u),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,r=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:C.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await O.onRequestError(e,t,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:S})},_),t}},d=await O.handleResponse({req:e,nextConfig:U,cacheKey:j,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:D,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:o});if(!I)return null;if((null==d||null==(i=d.value)?void 0:i.kind)!==C.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(l=d.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",S?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,R.fromNodeOutgoingHttpHeaders)(d.value.headers);return o&&I||c.delete(f.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,E.getCacheControlHeader)(d.cacheControl)),await (0,h.sendResponse)($,G,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};F?await l(F):await L.withPropagatedContext(e.headers,()=>L.trace(c.BaseServerSpan.handleRequest,{spanName:`${B} ${N}`,kind:i.SpanKind.SERVER,attributes:{"http.method":B,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await O.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:S})}),I)throw t;return await (0,h.sendResponse)($,G,new Response(null,{status:500})),null}}e.s(["handler",()=>w,"patchFetch",()=>A,"routeModule",()=>O,"serverHooks",()=>g,"workAsyncStorage",()=>x,"workUnitAsyncStorage",()=>U],7075)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__4575235f._.js.map