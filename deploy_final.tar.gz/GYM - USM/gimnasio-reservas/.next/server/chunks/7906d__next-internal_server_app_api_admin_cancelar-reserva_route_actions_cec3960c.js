module.exports=[19278,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_cancelar-reserva_route_actions_cec3960c.js.map