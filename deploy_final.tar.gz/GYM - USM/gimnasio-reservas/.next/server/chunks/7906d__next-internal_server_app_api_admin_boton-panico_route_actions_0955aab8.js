module.exports=[74591,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_boton-panico_route_actions_0955aab8.js.map