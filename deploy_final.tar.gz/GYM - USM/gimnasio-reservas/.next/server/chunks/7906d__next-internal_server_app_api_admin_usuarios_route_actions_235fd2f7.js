module.exports=[32680,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_usuarios_route_actions_235fd2f7.js.map