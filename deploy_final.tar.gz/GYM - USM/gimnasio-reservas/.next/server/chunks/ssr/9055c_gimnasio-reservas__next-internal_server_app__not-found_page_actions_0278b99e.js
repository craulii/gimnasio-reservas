module.exports=[56510,(a,b,c)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app__not-found_page_actions_0278b99e.js.map