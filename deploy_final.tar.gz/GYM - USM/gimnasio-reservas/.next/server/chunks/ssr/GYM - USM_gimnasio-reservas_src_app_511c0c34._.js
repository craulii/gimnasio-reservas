module.exports=[64392,a=>{a.v("/_next/static/media/favicon.f9bdc91c.ico")},27609,a=>{"use strict";let b={src:a.i(64392).default,width:806,height:711};a.s(["default",0,b])}];

//# sourceMappingURL=GYM%20-%20USM_gimnasio-reservas_src_app_511c0c34._.js.map