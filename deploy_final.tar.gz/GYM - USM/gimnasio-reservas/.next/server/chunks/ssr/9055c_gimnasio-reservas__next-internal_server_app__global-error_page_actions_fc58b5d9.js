module.exports=[91503,(a,b,c)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app__global-error_page_actions_fc58b5d9.js.map