module.exports=[27770,(a,b,c)=>{}];

//# sourceMappingURL=GYM%20-%20USM_gimnasio-reservas__next-internal_server_app_page_actions_a690f207.js.map