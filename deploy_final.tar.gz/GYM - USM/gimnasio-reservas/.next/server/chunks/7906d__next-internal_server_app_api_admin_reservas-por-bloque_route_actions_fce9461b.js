module.exports=[36605,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_reservas-por-bloque_route_actions_fce9461b.js.map