module.exports=[19398,(e,o,d)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app_api_test_route_actions_c82687c6.js.map