module.exports=[11135,(e,o,d)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app_api_reservas_route_actions_73b85553.js.map