module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},51348,e=>{"use strict";let t=e.i(46735).default.createPool({host:"127.0.0.1",port:3306,user:"reservas_crauli",password:"CrauliChris69!",database:"reservas_gymusm",waitForConnections:!0,connectionLimit:10,queueLimit:0});e.s(["default",0,t])},72625,e=>{"use strict";var t=e.i(32029),a=e.i(16524),r=e.i(74223),s=e.i(7239),o=e.i(55854),n=e.i(87601),i=e.i(17342),l=e.i(93396),c=e.i(33318),u=e.i(30644),d=e.i(31369),p=e.i(82742),E=e.i(62648),h=e.i(40693),R=e.i(68833),m=e.i(87703),f=e.i(93695);e.i(75916);var T=e.i(93173),v=e.i(51348);async function C(e){let t=e.headers.get("x-user");if(!t)return new Response("No autorizado",{status:401});if("admin"!==JSON.parse(t).rol)return new Response("Solo admin",{status:403});let{searchParams:a}=new URL(e.url),r=a.get("mes"),s=a.get("tipo")||"completo";try{let e,t;if(console.log(`[EXPORTAR] Tipo: ${s}, Mes: ${r||"último mes"}`),r){e=`${r}-01`;let[a,s]=r.split("-"),o=new Date(a,s,0).getDate();t=`${r}-${o.toString().padStart(2,"0")}`}else{let a=new Date;t=a.toISOString().split("T")[0],e=new Date(a.getFullYear(),a.getMonth()-3,a.getDate()).toISOString().split("T")[0]}let a="",o=`gimnasio_${s}_${r||"reciente"}.csv`;if("completo"===s){let[r]=await v.default.query(`
        SELECT 
          c.fecha,
          c.sede,
          c.bloque,
          c.total as cupos_totales,
          c.reservados as cupos_reservados,
          (c.total - c.reservados) as cupos_disponibles,
          COUNT(r.id) as reservas_realizadas,
          SUM(CASE WHEN r.asistio = 1 THEN 1 ELSE 0 END) as asistencias,
          SUM(CASE WHEN r.asistio = 0 THEN 1 ELSE 0 END) as inasistencias,
          ROUND(
            CASE 
              WHEN COUNT(r.id) > 0 THEN (SUM(CASE WHEN r.asistio = 1 THEN 1 ELSE 0 END) / COUNT(r.id)) * 100 
              ELSE 0 
            END, 2
          ) as porcentaje_asistencia,
          GROUP_CONCAT(DISTINCT u.name ORDER BY u.name SEPARATOR '; ') as usuarios_reservaron
        FROM cupos c
        LEFT JOIN reservas r ON c.bloque = r.bloque_horario AND c.fecha = r.fecha AND c.sede = r.sede
        LEFT JOIN users u ON r.email = u.email
        WHERE c.fecha BETWEEN ? AND ?
        GROUP BY c.fecha, c.sede, c.bloque
        ORDER BY c.fecha DESC, c.sede, c.bloque
      `,[e,t]);a="Fecha,Sede,Bloque,Cupos Totales,Cupos Reservados,Cupos Disponibles,Reservas Realizadas,Asistencias,Inasistencias,Porcentaje Asistencia,Usuarios\n",r.forEach(e=>{let t=e.fecha.toISOString().split("T")[0];a+=`${t},${e.sede},${e.bloque},${e.cupos_totales},${e.cupos_reservados},${e.cupos_disponibles},${e.reservas_realizadas},${e.asistencias},${e.inasistencias},${e.porcentaje_asistencia},"${e.usuarios_reservaron||"Sin reservas"}"
`})}else if("cupos"===s){let[r]=await v.default.query(`
        SELECT 
          fecha, 
          sede,
          bloque, 
          total, 
          reservados, 
          (total - reservados) as disponibles,
          ROUND((reservados / total) * 100, 2) as porcentaje_ocupacion
        FROM cupos 
        WHERE fecha BETWEEN ? AND ?
        ORDER BY fecha DESC, sede, bloque
      `,[e,t]);a="Fecha,Sede,Bloque,Total,Reservados,Disponibles,Porcentaje Ocupacion\n",r.forEach(e=>{let t=e.fecha.toISOString().split("T")[0];a+=`${t},${e.sede},${e.bloque},${e.total},${e.reservados},${e.disponibles},${e.porcentaje_ocupacion}
`})}else if("reservas"===s){let[r]=await v.default.query(`
        SELECT 
          r.fecha,
          r.sede,
          r.bloque_horario,
          u.name as nombre_usuario,
          u.rol,
          r.email,
          CASE WHEN r.asistio = 1 THEN 'Presente' ELSE 'Ausente' END as estado_asistencia,
          r.asistio as asistio_numerico,
          r.created_at as fecha_reserva
        FROM reservas r
        LEFT JOIN users u ON r.email = u.email
        WHERE r.fecha BETWEEN ? AND ?
        ORDER BY r.fecha DESC, r.sede, r.bloque_horario, u.name
      `,[e,t]);a="Fecha,Sede,Bloque,Nombre,ROL,Email,Estado,Asistio,Fecha Reserva\n",r.forEach(e=>{let t=e.fecha.toISOString().split("T")[0],r=e.fecha_reserva?e.fecha_reserva.toISOString().split("T")[0]:"N/A";a+=`${t},${e.sede},${e.bloque_horario},"${e.nombre_usuario||"Usuario eliminado"}",${e.rol||"N/A"},${e.email},${e.estado_asistencia},${e.asistio_numerico},${r}
`})}let n="\uFEFF"+a,i=a.split("\n").length-2;return console.log(`[EXPORTAR] Completado: ${o} (${i} registros)`),new Response(n,{status:200,headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="${o}"`,"Cache-Control":"no-cache"}})}catch(e){return console.error("[EXPORTAR] Error:",e),new Response(JSON.stringify({error:"Error exportando datos",message:e.message}),{status:500,headers:{"Content-Type":"application/json"}})}}async function O(e){let t=e.headers.get("x-user");if(!t)return new Response("No autorizado",{status:401});if("admin"!==JSON.parse(t).rol)return new Response("Solo admin",{status:403});try{let[e]=await v.default.query(`
      SELECT 
        DATE_FORMAT(fecha, '%Y-%m') as mes,
        COUNT(DISTINCT fecha) as dias_con_datos,
        MIN(fecha) as fecha_inicio,
        MAX(fecha) as fecha_fin,
        COUNT(*) as total_registros_cupos,
        (SELECT COUNT(*) FROM reservas WHERE DATE_FORMAT(fecha, '%Y-%m') = DATE_FORMAT(c.fecha, '%Y-%m')) as total_reservas,
        (SELECT COUNT(DISTINCT sede) FROM cupos WHERE DATE_FORMAT(fecha, '%Y-%m') = DATE_FORMAT(c.fecha, '%Y-%m')) as sedes_activas
      FROM cupos c
      WHERE fecha < DATE_FORMAT(CURDATE(), '%Y-%m-01')
      GROUP BY DATE_FORMAT(fecha, '%Y-%m')
      ORDER BY mes DESC
      LIMIT 12
    `),t=e.map(e=>{let[t,a]=e.mes.split("-"),r=new Date(t,a-1).toLocaleDateString("es-CL",{month:"long",year:"numeric"});return{...e,nombre:r.charAt(0).toUpperCase()+r.slice(1)}});return new Response(JSON.stringify({meses_disponibles:t,total_meses:e.length}),{status:200,headers:{"Content-Type":"application/json"}})}catch(e){return console.error("[EXPORTAR] Error obteniendo meses:",e),new Response(JSON.stringify({error:"Error interno",message:e.message}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["GET",()=>C,"POST",()=>O],54471);var g=e.i(54471);let N=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/admin/exportar/route",pathname:"/api/admin/exportar",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/GYM - USM/gimnasio-reservas/src/app/api/admin/exportar/route.js",nextConfigOutput:"standalone",userland:g}),{workAsyncStorage:S,workUnitAsyncStorage:_,serverHooks:x}=N;function A(){return(0,r.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:_})}async function w(e,t,r){N.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let v="/api/admin/exportar/route";v=v.replace(/\/index$/,"")||"/";let C=await N.prepare(e,t,{srcPage:v,multiZoneDraftMode:!1});if(!C)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:O,params:g,nextConfig:S,parsedUrl:_,isDraftMode:x,prerenderManifest:A,routerServerContext:w,isOnDemandRevalidate:D,revalidateOnlyGenerated:b,resolvedPathname:y,clientReferenceManifest:$,serverActionsManifest:q}=C,M=(0,l.normalizeAppPath)(v),U=!!(A.dynamicRoutes[M]||A.routes[y]),P=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,_,!1):t.end("This page could not be found"),null);if(U&&!x){let e=!!A.routes[y],t=A.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(S.experimental.adapterPath)return await P();throw new f.NoFallbackError}}let I=null;!U||N.isDev||x||(I="/index"===(I=y)?"/":I);let F=!0===N.isDev||!U,H=U&&!F;q&&$&&(0,n.setReferenceManifestsSingleton)({page:v,clientReferenceManifest:$,serverActionsManifest:q,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:q})});let L=e.method||"GET",j=(0,o.getTracer)(),k=j.getActiveScopeSpan(),B={params:g,prerenderManifest:A,renderOpts:{experimental:{authInterrupts:!!S.experimental.authInterrupts},cacheComponents:!!S.cacheComponents,supportsDynamicResponse:F,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:S.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r)=>N.onRequestError(e,t,r,w)},sharedContext:{buildId:O}},W=new c.NodeNextRequest(e),Y=new c.NodeNextResponse(t),G=u.NextRequestAdapter.fromNodeNextRequest(W,(0,u.signalFromNodeResponse)(t));try{let n=async e=>N.handle(G,B).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=j.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${L} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${L} ${v}`)}),i=!!(0,s.getRequestMeta)(e,"minimalMode"),l=async s=>{var o,l;let c=async({previousCacheEntry:a})=>{try{if(!i&&D&&b&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await n(s);e.fetchMetrics=B.renderOpts.fetchMetrics;let l=B.renderOpts.pendingWaitUntil;l&&r.waitUntil&&(r.waitUntil(l),l=void 0);let c=B.renderOpts.collectedTags;if(!U)return await (0,E.sendResponse)(W,Y,o,B.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(o.headers);c&&(t[m.NEXT_CACHE_TAGS_HEADER]=c),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==B.renderOpts.collectedRevalidate&&!(B.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&B.renderOpts.collectedRevalidate,r=void 0===B.renderOpts.collectedExpire||B.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:B.renderOpts.collectedExpire;return{value:{kind:T.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await N.onRequestError(e,t,{routerKind:"App Router",routePath:v,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:D})},w),t}},u=await N.handleResponse({req:e,nextConfig:S,cacheKey:I,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:D,revalidateOnlyGenerated:b,responseGenerator:c,waitUntil:r.waitUntil,isMinimalMode:i});if(!U)return null;if((null==u||null==(o=u.value)?void 0:o.kind)!==T.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(l=u.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",D?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),x&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,h.fromNodeOutgoingHttpHeaders)(u.value.headers);return i&&U||d.delete(m.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,R.getCacheControlHeader)(u.cacheControl)),await (0,E.sendResponse)(W,Y,new Response(u.value.body,{headers:d,status:u.value.status||200})),null};k?await l(k):await j.withPropagatedContext(e.headers,()=>j.trace(d.BaseServerSpan.handleRequest,{spanName:`${L} ${v}`,kind:o.SpanKind.SERVER,attributes:{"http.method":L,"http.target":e.url}},l))}catch(t){if(t instanceof f.NoFallbackError||await N.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:D})}),U)throw t;return await (0,E.sendResponse)(W,Y,new Response(null,{status:500})),null}}e.s(["handler",()=>w,"patchFetch",()=>A,"routeModule",()=>N,"serverHooks",()=>x,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>_],72625)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__04ca163b._.js.map