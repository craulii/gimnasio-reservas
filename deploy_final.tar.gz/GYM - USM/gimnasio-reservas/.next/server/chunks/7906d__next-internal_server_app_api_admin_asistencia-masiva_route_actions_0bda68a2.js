module.exports=[29008,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_asistencia-masiva_route_actions_0bda68a2.js.map