module.exports=[73056,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_estadisticas_route_actions_7e4d3c87.js.map