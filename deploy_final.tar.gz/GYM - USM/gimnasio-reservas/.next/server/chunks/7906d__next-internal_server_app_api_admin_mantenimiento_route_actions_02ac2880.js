module.exports=[98710,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_mantenimiento_route_actions_02ac2880.js.map