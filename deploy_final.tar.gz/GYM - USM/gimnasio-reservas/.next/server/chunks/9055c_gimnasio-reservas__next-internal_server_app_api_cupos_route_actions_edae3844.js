module.exports=[17040,(e,o,d)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app_api_cupos_route_actions_edae3844.js.map