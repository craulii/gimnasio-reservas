module.exports=[20786,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_procesar-ausencias_route_actions_2a8a27eb.js.map