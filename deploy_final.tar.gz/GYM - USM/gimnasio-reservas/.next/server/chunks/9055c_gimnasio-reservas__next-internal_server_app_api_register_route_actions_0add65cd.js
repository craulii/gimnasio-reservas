module.exports=[10287,(e,o,d)=>{}];

//# sourceMappingURL=9055c_gimnasio-reservas__next-internal_server_app_api_register_route_actions_0add65cd.js.map