module.exports=[16725,(e,o,d)=>{}];

//# sourceMappingURL=7906d__next-internal_server_app_api_admin_estadisticas-alumno_route_actions_3fa585ee.js.map