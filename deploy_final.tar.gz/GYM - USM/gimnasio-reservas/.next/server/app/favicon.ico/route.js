var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__84e7390b._.js")
R.c("server/chunks/9dba8_next_8e7e8f47._.js")
R.c("server/chunks/9dba8_next_dist_esm_build_templates_app-route_3387c5a2.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_favicon_ico_route_actions_643693a8.js")
R.m(69905)
module.exports=R.m(69905).exports
