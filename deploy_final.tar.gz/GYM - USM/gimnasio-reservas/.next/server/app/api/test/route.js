var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test/route.js")
R.c("server/chunks/[root-of-the-server]__f6a3ea68._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_api_test_route_actions_c82687c6.js")
R.m(42576)
module.exports=R.m(42576).exports
