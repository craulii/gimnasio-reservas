var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__8bab9449._.js")
R.c("server/chunks/9dba8_bcryptjs_index_3a99e7c5.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_api_register_route_actions_0add65cd.js")
R.m(40230)
module.exports=R.m(40230).exports
