var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cupos/route.js")
R.c("server/chunks/[root-of-the-server]__d1a9276b._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_api_cupos_route_actions_edae3844.js")
R.m(3471)
module.exports=R.m(3471).exports
