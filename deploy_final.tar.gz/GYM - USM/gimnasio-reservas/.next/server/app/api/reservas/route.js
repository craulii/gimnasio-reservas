var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reservas/route.js")
R.c("server/chunks/[root-of-the-server]__65ae6243._.js")
R.c("server/chunks/9dba8_bcryptjs_index_3a99e7c5.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_api_reservas_route_actions_73b85553.js")
R.m(90181)
module.exports=R.m(90181).exports
