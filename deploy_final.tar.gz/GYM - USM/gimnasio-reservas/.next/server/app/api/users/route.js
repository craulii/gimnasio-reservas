var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[root-of-the-server]__dd96809a._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/9055c_gimnasio-reservas__next-internal_server_app_api_users_route_actions_5e38df7e.js")
R.m(58342)
module.exports=R.m(58342).exports
