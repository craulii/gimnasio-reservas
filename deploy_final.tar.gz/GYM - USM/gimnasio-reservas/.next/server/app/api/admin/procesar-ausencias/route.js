var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/procesar-ausencias/route.js")
R.c("server/chunks/[root-of-the-server]__a309fd75._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_procesar-ausencias_route_actions_2a8a27eb.js")
R.m(63386)
module.exports=R.m(63386).exports
