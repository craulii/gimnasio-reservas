var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/usuarios/route.js")
R.c("server/chunks/[root-of-the-server]__5fd7aa79._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_usuarios_route_actions_235fd2f7.js")
R.m(90926)
module.exports=R.m(90926).exports
