var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/exportar/route.js")
R.c("server/chunks/[root-of-the-server]__04ca163b._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_exportar_route_actions_516d1e45.js")
R.m(72625)
module.exports=R.m(72625).exports
