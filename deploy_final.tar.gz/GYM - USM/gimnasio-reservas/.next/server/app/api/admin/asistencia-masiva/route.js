var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/asistencia-masiva/route.js")
R.c("server/chunks/[root-of-the-server]__882919fb._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_asistencia-masiva_route_actions_0bda68a2.js")
R.m(67751)
module.exports=R.m(67751).exports
