var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/cancelar-reserva/route.js")
R.c("server/chunks/[root-of-the-server]__12ac99c3._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_cancelar-reserva_route_actions_cec3960c.js")
R.m(95128)
module.exports=R.m(95128).exports
