var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/estadisticas-alumno/route.js")
R.c("server/chunks/[root-of-the-server]__c175964c._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_estadisticas-alumno_route_actions_3fa585ee.js")
R.m(86850)
module.exports=R.m(86850).exports
