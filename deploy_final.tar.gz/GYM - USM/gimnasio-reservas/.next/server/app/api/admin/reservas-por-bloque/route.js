var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reservas-por-bloque/route.js")
R.c("server/chunks/[root-of-the-server]__667fb2a4._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_reservas-por-bloque_route_actions_fce9461b.js")
R.m(51738)
module.exports=R.m(51738).exports
