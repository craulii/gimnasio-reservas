var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/estadisticas-bloque/route.js")
R.c("server/chunks/[root-of-the-server]__4575235f._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_estadisticas-bloque_route_actions_149b653b.js")
R.m(7075)
module.exports=R.m(7075).exports
