var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/boton-panico/route.js")
R.c("server/chunks/[root-of-the-server]__dc451f80._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_admin_boton-panico_route_actions_0955aab8.js")
R.m(93130)
module.exports=R.m(93130).exports
