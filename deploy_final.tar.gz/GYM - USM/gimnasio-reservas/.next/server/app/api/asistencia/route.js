var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/asistencia/route.js")
R.c("server/chunks/[root-of-the-server]__73bca98c._.js")
R.c("server/chunks/[root-of-the-server]__32f37826._.js")
R.c("server/chunks/[root-of-the-server]__cadda7b4._.js")
R.c("server/chunks/7906d__next-internal_server_app_api_asistencia_route_actions_a8ca4213.js")
R.m(1251)
module.exports=R.m(1251).exports
